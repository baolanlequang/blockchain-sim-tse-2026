package org.palladiosimulator.blockchainsystems.core.behavior

import org.palladiosimulator.blockchainsystems.core.common.BlockchainNodeObject
import org.palladiosimulator.blockchainsystems.core.common.abstractions.Event
import org.palladiosimulator.blockchainsystems.core.block.abstractions.Block
import org.palladiosimulator.blockchainsystems.core.system.abstractions.BlockchainSystemNodeBehavior
import org.palladiosimulator.blockchainsystems.core.system.abstractions.BlockchainSystemNodeContext
import org.palladiosimulator.blockchainsystems.core.transaction.abstractions.Transaction
import java.util.*
import java.util.random.RandomGenerator

/**
 * This behavior represents a node in the blockchain system that behaves honestly.
 *
 * @author Yannik Sproll
 */
class HonestBlockchainSystemNodeBehavior @JvmOverloads constructor(
  private val randomGenerator: RandomGenerator = RandomGenerator.of("Random")
) : BlockchainNodeObject(), BlockchainSystemNodeBehavior {
  override fun onBlockReceived(
    block: Block,
    context: BlockchainSystemNodeContext
  ) {
    context.blockValidator.validateBlock(block)
  }

  override fun onTransactionReceived(
    transaction: Transaction,
    context: BlockchainSystemNodeContext
  ) {
    context.trxMemPool.storeTransaction(transaction)
    context.transactionPropagationStrategy.distribute(transaction)
  }

  override fun onBlockValidated(block: Block, isValid: Boolean, context: BlockchainSystemNodeContext) {
    if (!isValid) return

    // Append the block; BehaviorUtils reconciles mempool state, including reorgs.
    val hasNewLongestChain = BehaviorUtils.appendBlockToBlockchain(block, context)
    if (hasNewLongestChain) {
      context.miningProcess.restartMining()
    }

    // Propagate the valid block to peers
    context.blockPropagationStrategy.distribute(block)
  }

  override fun onBlockMined(block: Block, context: BlockchainSystemNodeContext) {
    BehaviorUtils.appendBlockToBlockchain(block, context)
    context.blockPropagationStrategy.distribute(block)
  }

  override fun onCreatingBlock(
    blockMinedAt: Long,
    previousBlockHash: String,
    context: BlockchainSystemNodeContext
  ): Block {
    // Select transactions to include in the block
    val selectedTrxsResult = context.transactionSelectionProcess.selectTransactionsForBlock(context)

    // Transactions leave the mempool only once the mined block is accepted into
    // a local longest/forking branch; this avoids loss on stale/orphan outcomes.
    return context.blockFactory.createBlock(
      UUID(randomGenerator.nextLong(), randomGenerator.nextLong()).toString(),
      previousBlockHash,
      context.id,
      blockMinedAt,
      selectedTrxsResult.totalSize,
      selectedTrxsResult.transactions,
    )
  }

  override fun onPreviousBlockSelection(context: BlockchainSystemNodeContext): String {
    val blocks = context.blockchain.getLastBlocksOfLongestChains()
    return blocks.sortedBy { it.hash }.first().hash
  }

  override fun onNodeInitialized(context: BlockchainSystemNodeContext) {
    context.miningProcess.startMining()
  }

  override fun dispatchEvent(event: Event) {
  }
}