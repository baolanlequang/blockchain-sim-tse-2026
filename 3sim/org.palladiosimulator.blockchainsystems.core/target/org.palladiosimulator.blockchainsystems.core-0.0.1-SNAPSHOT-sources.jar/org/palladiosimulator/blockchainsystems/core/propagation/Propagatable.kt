package org.palladiosimulator.blockchainsystems.core.propagation

interface Propagatable
