package org.palladiosimulator.blockchainsystems.core.propagation.block

import org.palladiosimulator.blockchainsystems.core.block.abstractions.Block
import org.palladiosimulator.blockchainsystems.core.network.MessageDroppedTraceEvent
import org.palladiosimulator.blockchainsystems.core.utils.CompactStringStateMap
import org.palladiosimulator.blockchainsystems.core.scalability.ScalabilityStateTracker
import org.palladiosimulator.blockchainsystems.core.propagation.GossipPropagationStrategy
import org.palladiosimulator.blockchainsystems.core.propagation.MessageImpl
import org.palladiosimulator.blockchainsystems.core.system.abstractions.Message
import org.palladiosimulator.blockchainsystems.core.system.abstractions.P2PNetworkEndpoint

/**
 * Propagation strategy for blocks in a blockchain system.
 * This strategy handles the propagation of blocks through the network using a gossip protocol.
 *
 * @author Davis Riedel
 */
class BlockPropagationStrategy(
  private val scalabilityStateTracker: ScalabilityStateTracker? = null
) : GossipPropagationStrategy<Block>() {
  override val INV_MESSAGE_KEY: String = "BLOCK_INV"
  override val GET_DATA_MESSAGE_KEY: String = "BLOCK_GET_DATA"
  override val ELEMENT_MESSAGE_KEY: String = "BLOCK_MSG"

  private val MESSAGE_HEADER_BYTE_SIZE = 24
  private val INV_MESSAGE_BYTE_SIZE = 20
  private val GET_DATA_MESSAGE_BYTE_SIZE = 20

  /*
   * Keep block gossip idempotent while a received block is still waiting for
   * validation. Blockchain membership alone cannot suppress duplicates during
   * that interval because the block has not yet been appended.
   */
  // One entry records both protocol states: false = known-only, true = already announced.
  // This preserves duplicate-suppression semantics while avoiding two HashSet/HashMap
  // entries for the common case where a block is both known and announced.
  private val blockKnowledge = CompactStringStateMap(
    beforeNewEntry = { scalabilityStateTracker?.beforeBlockKnowledgeEntryAdded() },
    afterNewEntry = { nodeEntries -> scalabilityStateTracker?.onBlockKnowledgeEntryAdded(nodeEntries) }
  )

  /*
   * Lifecycle note: BlockchainNodeObject.onInitialize()/onCleanup() are final
   * protected hooks in this source revision. This per-strategy map therefore
   * rely on normal object construction for an empty initial state. Strategy
   * instances are per-node/per-run and are discarded with the simulation, so an
   * explicit lifecycle override is neither legal nor required.
   */


  override fun shouldAnnounce(element: Block): Boolean {
    return blockKnowledge.put(element.hash, STATE_ANNOUNCED) != STATE_ANNOUNCED
  }


  override fun createInvMessage(element: Block): Message {
    return MessageImpl(element.hash, INV_MESSAGE_KEY, MESSAGE_HEADER_BYTE_SIZE + INV_MESSAGE_BYTE_SIZE)
  }

  override fun createGetDataMessage(elementId: String): Message {
    return MessageImpl(elementId, GET_DATA_MESSAGE_KEY, MESSAGE_HEADER_BYTE_SIZE + GET_DATA_MESSAGE_BYTE_SIZE)
  }

  override fun createElementMessage(element: Block): Message {
    return MessageImpl(element, ELEMENT_MESSAGE_KEY, MESSAGE_HEADER_BYTE_SIZE + element.size)
  }


  override fun handleInvMessageReceived(
    message: Message,
    senderNetworkEndpoint: P2PNetworkEndpoint
  ) {
    context?.blockchain?.let { blockchain ->
      val hash = message.content as String
      if (blockKnowledge.containsKey(hash) || blockchain.hasBlockWithHash(hash)) {
        // Block already exists or is already being handled; no need to request it.
        return
      }
      networkInterface?.send(
        createGetDataMessage(hash),
        senderNetworkEndpoint
      )
    }
  }

  override fun handleGetDataMessageReceived(
    message: Message,
    senderNetworkEndpoint: P2PNetworkEndpoint
  ) {
    val hash = message.content as String
    context?.blockchain?.getBlock(hash)?.let { block ->
      networkInterface?.send(createElementMessage(block), senderNetworkEndpoint)
      logBlockSent(block, senderNetworkEndpoint)
    }
  }

  override fun handleElementMessageReceived(
    message: Message,
    senderNetworkEndpoint: P2PNetworkEndpoint
  ) {
    val block = message.content as Block

    // Suppress duplicate full-block deliveries before they can trigger duplicate
    // validation and redistribution. The first arrival still follows the original
    // validation/propagation path unchanged.
    if (!blockKnowledge.putIfAbsent(block.hash, STATE_KNOWN)) {
      return
    }

    logBlockReceived(block, senderNetworkEndpoint)
    notifyBlockReceived(block)
  }

  override fun handleMessageDropped(
    message: Message,
    recipientNetworkEndpoint: P2PNetworkEndpoint
  ) {
    if (networkInterface == null) throw IllegalStateException("Network interface is not set for BlockPropagationStrategy.")

    val event = MessageDroppedTraceEvent(
      message,
      simulationContext.systemClock.currentTime,
      recipientNetworkEndpoint,
      networkInterface!!
    )
    traceEventLogger.logEvent(event)
  }


  private companion object {
    const val STATE_KNOWN: Byte = 1
    const val STATE_ANNOUNCED: Byte = 2
  }


  private fun notifyBlockReceived(block: Block) {
    onReceivedCallback?.invoke(block)
  }

  private fun logBlockSent(block: Block, receiverNetworkEndpoint: P2PNetworkEndpoint) {
    val event = BlockSentTraceEvent(
      simulationContext.systemClock.currentTime,
      block,
      receiverNetworkEndpoint
    )
    traceEventLogger.logEvent(event)
  }

  private fun logBlockReceived(block: Block, senderNetworkEndpoint: P2PNetworkEndpoint) {
    val event = BlockReceivedTraceEvent(
      simulationContext.systemClock.currentTime,
      block,
      senderNetworkEndpoint
    )
    traceEventLogger.logEvent(event)
  }
}