package org.palladiosimulator.blockchainsystems.threesim.creation

import org.palladiosimulator.blockchainsystems.core.common.abstractions.SimulationContext
import org.palladiosimulator.blockchainsystems.core.common.abstractions.SimulationLifecycleAwareValueProvider
import org.palladiosimulator.blockchainsystems.bscm.p2pnetwork.ConnectivitySpecification


class BandwidthValueProvider(
  private val bandwidth: Double
) : SimulationLifecycleAwareValueProvider<Double> {
  override fun getValue(): Double? {
    return bandwidth
  }

  override fun initialize(simulationContext: SimulationContext) {
    // NOTE: No op, just for compatibility with the non-static bandwidth value provider interface
  }

  override fun cleanup() {
    // NOTE: No op, just for compatibility with the non-static bandwidth value provider interface
  }
}